# 🛡️ Accident Detector — Android App

ESP8266/ESP32 Accident Detection & Emergency Alert System

---

## ⚡ Get Your APK in 5 Minutes (GitHub Actions — Free)

### Step 1 — Create a GitHub Account
Go to https://github.com and sign up (free).

### Step 2 — Create a New Repository
- Click the **+** icon → **New repository**
- Name it: `AccidentDetector`
- Set to **Public** (required for free Actions minutes)
- Click **Create repository**

### Step 3 — Upload the Project Files
On your new repo page:
- Click **uploading an existing file**
- Drag & drop ALL the files/folders from this ZIP (keep the folder structure)
- Scroll down → click **Commit changes**

### Step 4 — Watch it Build
- Click the **Actions** tab in your repo
- You'll see **"Build Android APK"** workflow running automatically
- Wait ~3–5 minutes for it to complete ✅

### Step 5 — Download Your APK
- Click the completed workflow run
- Scroll to the bottom → **Artifacts** section
- Click **AccidentDetector-debug** to download the APK ZIP
- Extract it → you'll find `app-debug.apk`

### Step 6 — Install on Android
- Transfer the APK to your Android phone
- Go to **Settings → Install unknown apps** → allow your file manager
- Tap the APK file to install

---

## 📱 App Features
- Connects to ESP8266/ESP32 at `http://192.168.4.1/status`
- Polls every 2 seconds for state: `normal / alert / calling / stopped`
- Auto SMS + phone call when state = `calling`
- GPS location in SMS as Google Maps link
- Contact picker from phone book
- Vibration alerts
- All permissions handled at runtime

## 🔧 ESP JSON Format
Your ESP device must return:
```json
{ "state": "normal" }
```
Valid values: `normal`, `alert`, `calling`, `stopped`

---

## 🏗️ Build Locally (Android Studio)
1. Install Android Studio: https://developer.android.com/studio
2. Open this folder as a project
3. Let Gradle sync
4. Click **Build → Build Bundle(s)/APK(s) → Build APK(s)**
5. APK at: `app/build/outputs/apk/debug/app-debug.apk`
